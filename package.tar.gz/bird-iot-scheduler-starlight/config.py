from configparser import ConfigParser
from lib.logger_opt import *

config_file = './config.ini'
config = ConfigParser()
config.read(config_file)

version = ''

api_ai_service_capture = ''

param_ai_service_capture_trigger_interval = None

def get_version():
    return version
    
def check_config_section():
    if not config.has_section('common'):
        config.add_section('common')
        
    if not config.has_section('api'):
        config.add_section('api')
        
    if not config.has_section('param'):
        config.add_section('param')
        
    config.write(open(config_file, 'w'))
    
def get_config():
    global version, api_ai_service_capture, param_ai_service_capture_trigger_interval
    
    try:
        version = config.get('common', 'version')
    except Exception as e:
        logger.warning(e)
        version = ''
        
    try:
        api_ai_service_capture = config.get('api', 'ai_service_capture')
    except Exception as e:
        logger.warning(e)
        api_ai_service_capture = ''
        
    try:
        param_ai_service_capture_trigger_interval = int(config.get('param', 'ai_service_capture_trigger_interval'))
    except Exception as e:
        logger.warning(e)
        param_ai_service_capture_trigger_interval = 0
        
def reload_config():
    check_config_section()
    get_config()
    